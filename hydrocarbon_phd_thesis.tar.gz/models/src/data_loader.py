"""
Data Loader Module

Loads preprocessed CSV data from data_splitter output with one-hot encoded materials.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple

# Column definitions
TARGET_COLUMNS = ['carbon_material', 'carbon_transport', 'carbon_total', 'water_total']

# Material columns (34 one-hot encoded columns)
MATERIAL_COLUMNS = [
    'acrylic', 'cashmere', 'coated_fabric_pu', 'cotton_conventional', 'cotton_organic',
    'cotton_recycled', 'down_feather', 'down_synthetic', 'elastane', 'eva', 'hemp',
    'jute', 'leather_bovine', 'leather_ovine', 'leather_synthetic', 'linen_flax',
    'lyocell_tencel', 'metal_brass', 'metal_gold', 'metal_silver', 'metal_steel',
    'modal', 'natural_rubber', 'polyamide_6', 'polyamide_66', 'polyamide_recycled',
    'polyester_recycled', 'polyester_virgin', 'rubber_synthetic', 'silk', 'tpu',
    'viscose', 'wool_generic', 'wool_merino'
]

# Categorical columns
CATEGORICAL_COLUMNS = ['gender', 'parent_category', 'category']

# Numerical columns
NUMERICAL_COLUMNS = ['weight_kg', 'total_distance_km']

# All feature columns (excluding product_name and manufacturer_country per plan)
FEATURE_COLUMNS = CATEGORICAL_COLUMNS + NUMERICAL_COLUMNS + MATERIAL_COLUMNS


def load_data(
    train_path: str = None,
    val_path: str = None,
    sample_size: int = None,
    remove_outliers: bool = True,
    outlier_percentile: float = 0.999
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Load training and validation data from CSV files.
    
    Args:
        train_path: Path to training CSV (auto-detects if None)
        val_path: Path to validation CSV (auto-detects if None)
        sample_size: If set, load only this many rows (for quick testing)
        remove_outliers: If True, remove samples with extreme target values
        outlier_percentile: Percentile threshold for outlier removal (default 99.9%)
        
    Returns:
        X_train, y_train, X_val, y_val
    """
    # Auto-detect paths relative to this file's location
    if train_path is None:
        base_dir = Path(__file__).resolve().parent.parent.parent  # models/src -> models -> bulk_product_generator
        train_path = base_dir / 'data' / 'data_splitter' / 'output' / 'train.csv'
    if val_path is None:
        base_dir = Path(__file__).resolve().parent.parent.parent
        val_path = base_dir / 'data' / 'data_splitter' / 'output' / 'validate.csv'
    
    print(f"Loading training data from {train_path}...")
    if sample_size:
        print(f"  [Quick test mode: loading only {sample_size} samples]")
        train_df = pd.read_csv(train_path, nrows=sample_size, on_bad_lines='warn', quotechar='"')
        val_df = pd.read_csv(val_path, nrows=sample_size // 4, on_bad_lines='warn', quotechar='"')
    else:
        train_df = pd.read_csv(train_path, on_bad_lines='warn', quotechar='"')
        val_df = pd.read_csv(val_path, on_bad_lines='warn', quotechar='"')
    
    print(f"  Loaded {len(train_df):,} training samples")
    print(f"  Loaded {len(val_df):,} validation samples")
    
    # Validate columns exist
    missing_features = set(FEATURE_COLUMNS) - set(train_df.columns)
    if missing_features:
        raise ValueError(f"Missing feature columns: {missing_features}")
    
    missing_targets = set(TARGET_COLUMNS) - set(train_df.columns)
    if missing_targets:
        raise ValueError(f"Missing target columns: {missing_targets}")
    
    # Split features and targets
    X_train = train_df[FEATURE_COLUMNS].copy()
    y_train = train_df[TARGET_COLUMNS].copy()
    
    X_val = val_df[FEATURE_COLUMNS].copy()
    y_val = val_df[TARGET_COLUMNS].copy()
    
    # Remove outliers (extreme values that are likely data errors)
    if remove_outliers:
        n_train_before = len(X_train)
        n_val_before = len(X_val)
        
        # Calculate thresholds from training data
        thresholds = {}
        for col in TARGET_COLUMNS:
            thresholds[col] = y_train[col].quantile(outlier_percentile)
        
        # Create mask for valid samples (non-negative and below threshold)
        train_mask = pd.Series(True, index=y_train.index)
        val_mask = pd.Series(True, index=y_val.index)
        
        for col in TARGET_COLUMNS:
            train_mask &= (y_train[col] >= 0) & (y_train[col] <= thresholds[col])
            val_mask &= (y_val[col] >= 0) & (y_val[col] <= thresholds[col])
        
        # Apply masks
        X_train = X_train[train_mask].reset_index(drop=True)
        y_train = y_train[train_mask].reset_index(drop=True)
        X_val = X_val[val_mask].reset_index(drop=True)
        y_val = y_val[val_mask].reset_index(drop=True)
        
        n_train_removed = n_train_before - len(X_train)
        n_val_removed = n_val_before - len(X_val)
        
        print(f"\n[OUTLIER REMOVAL] Removed samples outside [0, {outlier_percentile*100:.1f}th percentile]:")
        print(f"  Training: {n_train_removed:,} removed ({100*n_train_removed/n_train_before:.2f}%), {len(X_train):,} remaining")
        print(f"  Validation: {n_val_removed:,} removed ({100*n_val_removed/n_val_before:.2f}%), {len(X_val):,} remaining")
        print(f"  Thresholds: carbon_material≤{thresholds['carbon_material']:.1f}, "
              f"carbon_transport≤{thresholds['carbon_transport']:.2f}, "
              f"water_total≤{thresholds['water_total']:.0f}")
    
    # Data validation
    print(f"\n[OK] Data loaded successfully")
    print(f"  Features: {len(FEATURE_COLUMNS)} ({len(CATEGORICAL_COLUMNS)} categorical, "
          f"{len(NUMERICAL_COLUMNS)} numerical, {len(MATERIAL_COLUMNS)} materials)")
    print(f"  Targets: {len(TARGET_COLUMNS)}")
    print(f"  Missing values in training:")
    for col in NUMERICAL_COLUMNS:
        missing_pct = (X_train[col].isna().sum() / len(X_train)) * 100
        if missing_pct > 0:
            print(f"    {col}: {missing_pct:.1f}%")
    
    return X_train, y_train, X_val, y_val


def get_material_dataset_path():
    """Get path to material emission factors dataset"""
    base_dir = Path(__file__).resolve().parent.parent.parent  # models/src -> models -> bulk_product_generator
    return base_dir / 'data' / 'data_calculations' / 'input' / 'material_dataset_final.csv'


if __name__ == '__main__':
    # Test the data loader
    X_train, y_train, X_val, y_val = load_data(sample_size=1000)
    
    print("\nSample features:")
    print(X_train.head(2))
    print("\nSample targets:")
    print(y_train.head(2))
    print("\nData types:")
    print(X_train.dtypes.value_counts())
